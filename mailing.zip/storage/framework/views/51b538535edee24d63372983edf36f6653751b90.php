<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>
        <?php echo $text; ?>

    </div>
    <br>
    <div>
        <?php if($files): ?>
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                ֆայլ - <a href="<?php echo e(env('app_url').$file[1]); ?>" target="_blank" download><?php echo e($file[0]); ?></a> <br> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp8.1\htdocs\mailing\resources\views/email/email.blade.php ENDPATH**/ ?>