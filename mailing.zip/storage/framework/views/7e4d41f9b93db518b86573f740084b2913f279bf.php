<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div style="width: 300px; text-align: center">
        <div>
            <a href="<?php echo e($data['imgLink']); ?>">
                <img style="width: 100%" src="https://ymail.yerevak.am<?php echo e($data['image'][0][1]); ?>" alt="">
            </a>
        </div>
    </div>
    <br>
    <div>
        <?php if($files): ?>
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                ֆայլ - <a target="_blank" href="https://ymail.yerevak.am<?php echo e($file[1]); ?>" download><?php echo e($file[0]); ?></a> <br> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <br>
    <br>
    <div>
        <?php if($data['mailingImg'] != 'null'): ?>
            <a href="<?php echo e($data['bottom_img_link']); ?>" target="_blank">
                <img src="https://ymail.yerevak.am<?php echo e($data['mailingImg']); ?>">
            </a>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp8.1\htdocs\mailing\resources\views/email/template1.blade.php ENDPATH**/ ?>